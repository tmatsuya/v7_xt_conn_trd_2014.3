#!/bin/sh

cd linux_driver_app/

sudo chmod +x *.sh
sudo chmod +x util/quadnic_setup
sudo sh rungui.sh
